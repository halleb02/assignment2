import UIKit

import Foundation

func calculateMortgagePayment1(loanAmount: Int, numberOfPayments: Int, interestRate: Float) -> Float {
    let monthlyInterestRate = interestRate / 12 / 100
    let numerator = Float(loanAmount) * monthlyInterestRate
    let denominator = 1 - pow(1 + monthlyInterestRate, -Float(numberOfPayments))
    
    let payment = numerator / denominator
    return payment
}

func calculateMortgagePayment2(loanAmount: Int, numberOfPayments: Int, interestRate: Float) -> Float {
    let interestRate = interestRate / 100
    let numerator = Float(loanAmount) * interestRate
    let denominator = 1 - pow(1 + interestRate, -Float(numberOfPayments))
    
    let payment = numerator / denominator
    return payment
    
}

// 2-month loan of $20,000, 4.4% APR, compounded monthly
let payment1 = calculateMortgagePayment1(loanAmount: 20000, numberOfPayments: 2, interestRate: 4.4)
print("Payment for a 2-month loan at 4.4% APR, compounded monthly: $\(String(format: "%.2f", payment1))")

// 30-year loan of $150,000, 5% APR, one annual payment each year for 30 years
let payment2 = calculateMortgagePayment2(loanAmount: 150000, numberOfPayments: 30, interestRate: 5)
print("Payment for a 30-year loan at 5% APR, one annual payment each year for 30 years: $\(String(format: "%.2f", payment2))")
